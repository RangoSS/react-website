//declaration
//assignment
//processing
//displaying
